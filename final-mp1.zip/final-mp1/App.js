import React from 'react';
import { View, StyleSheet } from 'react-native';
import VCard from './Vcard';

const App = () => {
  return (
    <View style={styles.container}>
      <VCard 
        name="Jay-r Salazar"
        occupation="Software Developer"
        email="jayrr4554@gmail.com"
        contactNo="09666518581"
        dob="Septemerber 13,2001"
        location="Caloocan City"
        profilePic={require('./unnamed.jpg')}
        coverPhoto={require('./jayr.jpg')}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
    padding: 20,
  },
});

export default App;